// "use client";
// import React, { useState, useRef } from "react";
// import { BookOpen } from "lucide-react";

// const achievements = [
//   {
//     id: 1,
//     logo: "/assets/un1.png",
//     percentage: "98%",
//     studentName: "TANIYA SHARMA",
//     course: "LOREM IPSUM DOLOR SIT",
//   },
//   {
//     id: 2,
//     logo: "/assets/un2.png",
//     percentage: "98%",
//     studentName: "TANIYA SHARMA",
//     course: "LOREM IPSUM DOLOR SIT",
//   },
//   {
//     id: 3,
//     logo: "/assets/un3.png",
//     percentage: "98%",
//     studentName: "TANIYA SHARMA",
//     course: "LOREM IPSUM DOLOR SIT",
//   },
//   {
//     id: 4,
//     logo: "/assets/un1.png",
//     percentage: "95%",
//     studentName: "RAHUL VERMA",
//     course: "LOREM IPSUM DOLOR SIT",
//   },
//   {
//     id: 5,
//     logo: "/assets/un2.png",
//     percentage: "97%",
//     studentName: "PRIYA PATEL",
//     course: "LOREM IPSUM DOLOR SIT",
//   },
// ];

// export default function StudentAchievements() {
//   const [currentIndex, setCurrentIndex] = useState(0);
//   const [isDragging, setIsDragging] = useState(false);
//   const [startX, setStartX] = useState(0);
//   const [scrollLeft, setScrollLeft] = useState(0);
//   const sliderRef = useRef(null);
//   const [visibleCards, setVisibleCards] = useState(3); // Default to 3 cards

//   // Determine number of visible cards based on screen size
//   const updateVisibleCards = () => {
//     const width = window.innerWidth;
//     if (width < 768) {
//       setVisibleCards(1);
//     } else if (width < 1024) {
//       setVisibleCards(2);
//     } else {
//       setVisibleCards(3);
//     }
//   };

//   // Initialize and handle resize
//   React.useEffect(() => {
//     updateVisibleCards();
//     window.addEventListener('resize', updateVisibleCards);
//     return () => window.removeEventListener('resize', updateVisibleCards);
//   }, []);

//   const handlePrev = () => {
//     setCurrentIndex(prev => 
//       prev === 0 ? achievements.length - visibleCards : prev - 1
//     );
//   };

//   const handleNext = () => {
//     setCurrentIndex(prev => 
//       prev >= achievements.length - visibleCards ? 0 : prev + 1
//     );
//   };

//   const goToSlide = (index) => {
//     setCurrentIndex(index);
//   };

//   // Handle mouse events for dragging
//   const handleMouseDown = (e) => {
//     setIsDragging(true);
//     setStartX(e.pageX - sliderRef.current.offsetLeft);
//     setScrollLeft(sliderRef.current.scrollLeft);
//   };

//   const handleMouseLeave = () => {
//     setIsDragging(false);
//   };

//   const handleMouseUp = () => {
//     setIsDragging(false);
//   };

//   const handleMouseMove = (e) => {
//     if (!isDragging) return;
//     e.preventDefault();
//     const x = e.pageX - sliderRef.current.offsetLeft;
//     const walk = (x - startX) * 2; // Adjust scroll speed
//     sliderRef.current.scrollLeft = scrollLeft - walk;
//   };

//   // Handle touch events for mobile
//   const handleTouchStart = (e) => {
//     setIsDragging(true);
//     setStartX(e.touches[0].pageX - sliderRef.current.offsetLeft);
//     setScrollLeft(sliderRef.current.scrollLeft);
//   };

//   const handleTouchMove = (e) => {
//     if (!isDragging) return;
//     const x = e.touches[0].pageX - sliderRef.current.offsetLeft;
//     const walk = (x - startX) * 2;
//     sliderRef.current.scrollLeft = scrollLeft - walk;
//   };

//   // Calculate which cards to display based on currentIndex and visibleCards
//   const getVisibleAchievements = () => {
//     let cards = [];
//     for (let i = 0; i < visibleCards; i++) {
//       const index = (currentIndex + i) % achievements.length;
//       cards.push(achievements[index]);
//     }
//     return cards;
//   };

//   return (
//     <div
//       className="w-100 py-5 fade-in-section mx-auto"
//       data-scroll
//       data-scroll-class="is-inview"
//       data-scroll-repeat
//       style={{ animationDelay: "0.1s", maxWidth:"90vw" }}
//     >
//       <div className="container px-4">
//         {/* Header Section */}
//         <div
//           className="text-center mb-5 fade-in-section"
//           data-scroll
//           data-scroll-class="is-inview"
//           data-scroll-repeat
//           style={{ animationDelay: "0.15s" }}
//         >
//           {/* Gradient subtitle with lines */}
//           <div
//             className="d-flex align-items-center justify-content-center gap-3 mb-3 fade-in-section"
//             data-scroll
//             data-scroll-class="is-inview"
//             data-scroll-repeat
//             style={{ animationDelay: "0.2s" }}
//           >
//             <h3
//               className="text-uppercase fw-bold mb-0 fade-in-section"
//               data-scroll
//               data-scroll-class="is-inview"
//               data-scroll-repeat
//               style={{
//                 letterSpacing: "3px",
//                 background: "linear-gradient(135deg, #3F88BA, #161664)",
//                 WebkitBackgroundClip: "text",
//                 WebkitTextFillColor: "transparent",
//                 fontSize: "clamp(1rem, 2.5vw, 1.5rem)",
//                 animationDelay: "0.25s"
//               }}
//             >
//               <img
//                 src="/assets/3color.png"
//                 alt="act"
//                 width={15}
//                 height={18}
//                 style={{ verticalAlign: "middle", marginLeft: "0.5rem" }}
//               />{" "}
//               STUDENT ACHIEVEMENTS{" "}
//               <img
//                 src="/assets/3color.png"
//                 alt="act"
//                 width={15}
//                 height={18}
//                 style={{ verticalAlign: "middle", marginLeft: "0.5rem" }}
//               />
//             </h3>
//           </div>

//           {/* Main title */}
//           <h2
//             className="fw-bold display-6 lh-tight mb-0 fade-in-section"
//             data-scroll
//             data-scroll-class="is-inview"
//             data-scroll-repeat
//             style={{ animationDelay: "0.3s" }}
//           >
//             <span
//               style={{
//                 background: "linear-gradient(135deg, #3F88BA, #161664)",
//                 WebkitBackgroundClip: "text",
//                 WebkitTextFillColor: "transparent"
//               }}
//             >
//               LOREM IPSUM DOLOR SIT AMET,
//             </span>{" "}
//             <span
//               style={{
//                 background: "linear-gradient(135deg, #00A491, #003E37)",
//                 WebkitBackgroundClip: "text",
//                 WebkitTextFillColor: "transparent"
//               }}
//             >
//               CONSECTETUR
//             </span>{" "}
//             <span
//               style={{
//                 background: "linear-gradient(135deg, #3F88BA, #161664)",
//                 WebkitBackgroundClip: "text",
//                 WebkitTextFillColor: "transparent"
//               }}
//             >
//               ADIPISCING
//             </span>
//           </h2>
//         </div>

//         {/* Slider Section */}
//         <div
//           className="position-relative fade-in-section"
//           data-scroll
//           data-scroll-class="is-inview"
//           data-scroll-repeat
//           style={{ animationDelay: "0.35s" }}
//         >
//           {/* Left Arrow */}
//           <button
//             onClick={handlePrev}
//             className="btn rounded-circle position-absolute d-flex align-items-center justify-content-center border-0 fade-in-section"
//             data-scroll
//             data-scroll-class="is-inview"
//             data-scroll-repeat
//             style={{
//               background: "#1e40af",
//               width: "48px",
//               height: "48px",
//               left: "-10px",
//               top: "50%",
//               transform: "translateY(-50%)",
//               zIndex: 10,
//               color: "white",
//               animationDelay: "0.4s"
//             }}
//           >
//             <img src="/assets/lar.png" alt="rightarr" width={50} height={50} />
//           </button>

//           {/* Cards Container */}
//           <div
//             ref={sliderRef}
//             className="d-flex gap-4 px-5"
//             style={{
//               width: "100%",
//               cursor: isDragging ? "grabbing" : "grab",
//               scrollBehavior: "smooth",
//               overflowX: "auto",
//               scrollbarWidth: "none",
//               msOverflowStyle: "none",
//             }}
//             onMouseDown={handleMouseDown}
//             onMouseLeave={handleMouseLeave}
//             onMouseUp={handleMouseUp}
//             onMouseMove={handleMouseMove}
//             onTouchStart={handleTouchStart}
//             onTouchMove={handleTouchMove}
//             onTouchEnd={handleMouseUp}
//           >
//             {/* Show cards based on visibleCards */}
//             {getVisibleAchievements().map((achievement, index) => (
//               <div
//                 key={`${achievement.id}-${currentIndex}`}
//                 className="rounded-4 text-center position-relative flex-shrink-0"
//                 style={{
//                   width: `calc(${100 / visibleCards}% - ${(visibleCards - 1) * 16}px)`,
//                   minWidth: "300px",
//                   height: "400px",
//                   backgroundColor: "#FFFFFF",
//                   transition: "all 0.3s ease",
//                   overflow: "hidden",
//                 }}
//               >
//                 {/* Logo Background Area */}
//                 <div
//                   className="position-relative d-flex align-items-center justify-content-center"
//                   style={{
//                     height: "250px",
//                     backgroundColor: "#d1d5db",
//                     borderRadius: "1.5rem 1.5rem 0 0",
//                   }}
//                 >
//                   <img
//                     src={achievement.logo}
//                     alt="University Logo"
//                     className="rounded"
//                     style={{
//                       width: "250px",
//                       height: "250px",
//                       objectFit: "contain",
//                       padding: "8px",
//                       mixBlendMode: "multiply",
//                     }}
//                   />

//                   {/* White rounded cutout for percentage - extends to edge */}
//                   <div
//                     className="position-absolute"
//                     style={{
//                       bottom: "0px",
//                       right: "0px",
//                       width: "100px",
//                       height: "65px",
//                       backgroundColor: "#FFFFFF",
//                       borderRadius: "25px 0 0 0",
//                     }}
//                   ></div>

//                   {/* Percentage positioned in the cutout */}
//                   <div
//                     className="position-absolute fw-bold d-flex align-items-center"
//                     style={{
//                       bottom: "0px",
//                       right: "0px",
//                       width: "100px",
//                       height: "65px",
//                       fontSize: "2.5rem",
//                       fontWeight: "800",
//                       paddingLeft: "8px",
//                       paddingRight: "8px",
//                       background: "linear-gradient(90deg, #3F88BA, #161664)",
//                       WebkitBackgroundClip: "text",
//                       WebkitTextFillColor: "transparent",
//                       backgroundClip: "text",
//                     }}
//                   >
//                     {achievement.percentage}
//                   </div>
//                 </div>

//                 {/* Content Area */}
//                 <div
//                   className="p-4"
//                   style={{
//                     height: "150px",
//                   }}
//                 >
//                   <div className="mb-3">
//                     <h4
//                       className="fw-bold mb-0 text-start"
//                       style={{
//                         background: "linear-gradient(90deg, #00A491, #003E37)",
//                         WebkitBackgroundClip: "text",
//                         WebkitTextFillColor: "transparent",
//                         backgroundClip: "text",
//                         fontSize: "1.2rem",
//                         letterSpacing: "0.5px",
//                         textAlign: "left"
//                       }}
//                     >
//                       {achievement.studentName}
//                     </h4>
//                   </div>

//                   {/* Course with border */}
//                   <div className="pt-3 border-top border-secondary">
//                     <div className="d-flex gap-2">
//                       <BookOpen size={16} />
//                       <span
//                         className="fw-semibold"
//                         style={{
//                           fontSize: "0.9rem",
//                           letterSpacing: "0.5px",
//                           background: "linear-gradient(90deg, #3F88BA, #161664)",
//                           WebkitBackgroundClip: "text",
//                           WebkitTextFillColor: "transparent",
//                           backgroundClip: "text",
//                         }}
//                       >
//                         {achievement.course}
//                       </span>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//             ))}
//           </div>

//           {/* Right Arrow */}
//           <button
//             onClick={handleNext}
//             className="btn rounded-circle position-absolute d-flex align-items-center justify-content-center border-0 fade-in-section"
//             data-scroll
//             data-scroll-class="is-inview"
//             data-scroll-repeat
//             style={{
//               background: "#1e40af",
//               width: "48px",
//               height: "48px",
//               right: "-10px",
//               top: "50%",
//               transform: "translateY(-50%)",
//               zIndex: 10,
//               color: "white",
//               animationDelay: "1.1s"
//             }}
//           >
//             <img src="/assets/rar.png" alt="rightarr" width={50} height={50} />
//           </button>
//         </div>

//         {/* Navigation Dots */}
//         <div className="d-flex justify-content-center mt-4 gap-2">
//           {Array.from({ length: achievements.length - visibleCards + 1 }).map((_, index) => (
//             <button
//               key={index}
//               onClick={() => goToSlide(index)}
//               className="border-0 rounded-circle"
//               style={{
//                 width: "12px",
//                 height: "12px",
//                 backgroundColor: currentIndex === index ? "#1e40af" : "#d1d5db",
//                 transition: "all 0.3s ease",
//                 transform: currentIndex === index ? "scale(1.2)" : "scale(1)"
//               }}
//             />
//           ))}
//         </div>
//       </div>

//       <style jsx>{`
//         .fade-in-section {
//           opacity: 0;
//           transform: translateY(20px);
//           transition: opacity 0.6s ease-out, transform 0.6s ease-out;
//         }
//         .fade-in-section.is-inview {
//           opacity: 1;
//           transform: translateY(0);
//         }
//       `}</style>
//     </div>
//   );
// }









"use client";
import React, { useState, useRef } from "react";
import { BookOpen } from "lucide-react";

const achievements = [
  {
    id: 1,
    logo: "/assets/un1.png",
    percentage: "98%",
    studentName: "TANIYA SHARMA",
    course: "LOREM IPSUM DOLOR SIT",
  },
  {
    id: 2,
    logo: "/assets/un2.png",
    percentage: "98%",
    studentName: "TANIYA SHARMA",
    course: "LOREM IPSUM DOLOR SIT",
  },
  {
    id: 3,
    logo: "/assets/un3.png",
    percentage: "98%",
    studentName: "TANIYA SHARMA",
    course: "LOREM IPSUM DOLOR SIT",
  },
  {
    id: 4,
    logo: "/assets/un1.png",
    percentage: "95%",
    studentName: "RAHUL VERMA",
    course: "LOREM IPSUM DOLOR SIT",
  },
  {
    id: 5,
    logo: "/assets/un2.png",
    percentage: "97%",
    studentName: "PRIYA PATEL",
    course: "LOREM IPSUM DOLOR SIT",
  },
];

export default function StudentAchievements() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const [startX, setStartX] = useState(0);
  const [scrollLeft, setScrollLeft] = useState(0);
  const sliderRef = useRef(null);
  const [visibleCards, setVisibleCards] = useState(3); // Default to 3 cards

  // Determine number of visible cards based on screen size
  const updateVisibleCards = () => {
    const width = window.innerWidth;
    if (width < 768) {
      setVisibleCards(1);
    } else if (width < 1024) {
      setVisibleCards(2);
    } else {
      setVisibleCards(3);
    }
  };

  // Initialize and handle resize
  React.useEffect(() => {
    updateVisibleCards();
    window.addEventListener('resize', updateVisibleCards);
    return () => window.removeEventListener('resize', updateVisibleCards);
  }, []);

  const handlePrev = () => {
    setCurrentIndex(prev => 
      prev === 0 ? achievements.length - visibleCards : prev - 1
    );
  };

  const handleNext = () => {
    setCurrentIndex(prev => 
      prev >= achievements.length - visibleCards ? 0 : prev + 1
    );
  };

  const goToSlide = (index) => {
    setCurrentIndex(index);
  };

  // Handle mouse events for dragging
  const handleMouseDown = (e) => {
    setIsDragging(true);
    setStartX(e.pageX - sliderRef.current.offsetLeft);
    setScrollLeft(sliderRef.current.scrollLeft);
  };

  const handleMouseLeave = () => {
    setIsDragging(false);
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleMouseMove = (e) => {
    if (!isDragging) return;
    e.preventDefault();
    const x = e.pageX - sliderRef.current.offsetLeft;
    const walk = (x - startX) * 2; // Adjust scroll speed
    sliderRef.current.scrollLeft = scrollLeft - walk;
  };

  // Handle touch events for mobile
  const handleTouchStart = (e) => {
    setIsDragging(true);
    setStartX(e.touches[0].pageX - sliderRef.current.offsetLeft);
    setScrollLeft(sliderRef.current.scrollLeft);
  };

  const handleTouchMove = (e) => {
    if (!isDragging) return;
    const x = e.touches[0].pageX - sliderRef.current.offsetLeft;
    const walk = (x - startX) * 2;
    sliderRef.current.scrollLeft = scrollLeft - walk;
  };

  // Calculate which cards to display based on currentIndex and visibleCards
  const getVisibleAchievements = () => {
    let cards = [];
    for (let i = 0; i < visibleCards; i++) {
      const index = (currentIndex + i) % achievements.length;
      cards.push(achievements[index]);
    }
    return cards;
  };

  return (
    <div
      className="w-100 py-5 fade-in-section mx-auto"
      data-scroll
      data-scroll-class="is-inview"
      data-scroll-repeat
      style={{ animationDelay: "0.1s", maxWidth:"90vw" }}
    >
      <div className="container px-4">
        {/* Header Section */}
        <div
          className="text-center mb-5 fade-in-section"
          data-scroll
          data-scroll-class="is-inview"
          data-scroll-repeat
          style={{ animationDelay: "0.15s" }}
        >
          {/* Gradient subtitle with lines */}
          <div
            className="d-flex align-items-center justify-content-center gap-3 mb-3 fade-in-section"
            data-scroll
            data-scroll-class="is-inview"
            data-scroll-repeat
            style={{ animationDelay: "0.2s" }}
          >
            <h3
              className="text-uppercase fw-bold mb-0 fade-in-section"
              data-scroll
              data-scroll-class="is-inview"
              data-scroll-repeat
              style={{
                letterSpacing: "3px",
                background: "linear-gradient(135deg, #3F88BA, #161664)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                fontSize: "clamp(1rem, 2.5vw, 1.5rem)",
                animationDelay: "0.25s"
              }}
            >
              <img
                src="/assets/3color.png"
                alt="act"
                width={15}
                height={18}
                style={{ verticalAlign: "middle", marginLeft: "0.5rem" }}
              />{" "}
              STUDENT ACHIEVEMENTS{" "}
              <img
                src="/assets/3color.png"
                alt="act"
                width={15}
                height={18}
                style={{ verticalAlign: "middle", marginLeft: "0.5rem" }}
              />
            </h3>
          </div>

          {/* Main title */}
          <h2
            className="fw-bold display-6 lh-tight mb-0 fade-in-section"
            data-scroll
            data-scroll-class="is-inview"
            data-scroll-repeat
            style={{ animationDelay: "0.3s" }}
          >
            <span
              style={{
                background: "linear-gradient(135deg, #3F88BA, #161664)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent"
              }}
            >
              LOREM IPSUM DOLOR SIT AMET,
            </span>{" "}
            <span
              style={{
                background: "linear-gradient(135deg, #00A491, #003E37)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent"
              }}
            >
              CONSECTETUR
            </span>{" "}
            <span
              style={{
                background: "linear-gradient(135deg, #3F88BA, #161664)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent"
              }}
            >
              ADIPISCING
            </span>
          </h2>
        </div>

        {/* Slider Section */}
        <div
          className="position-relative fade-in-section"
          data-scroll
          data-scroll-class="is-inview"
          data-scroll-repeat
          style={{ animationDelay: "0.35s" }}
        >
          {/* Left Arrow */}
          <button
            onClick={handlePrev}
            className="btn rounded-circle position-absolute d-flex align-items-center justify-content-center border-0 fade-in-section"
            data-scroll
            data-scroll-class="is-inview"
            data-scroll-repeat
            style={{
              background: "#1e40af",
              width: "48px",
              height: "48px",
              left: "-10px",
              top: "50%",
              transform: "translateY(-50%)",
              zIndex: 10,
              color: "white",
              animationDelay: "0.4s"
            }}
          >
            <img src="/assets/lar.png" alt="rightarr" width={50} height={50} />
          </button>

          {/* Cards Container */}
          <div
            ref={sliderRef}
            className="d-flex gap-4 px-5"
            style={{
              width: "100%",
              cursor: isDragging ? "grabbing" : "grab",
              scrollBehavior: "smooth",
              overflowX: "hidden",
              scrollbarWidth: "none",
              msOverflowStyle: "none",
            }}
            onMouseDown={handleMouseDown}
            onMouseLeave={handleMouseLeave}
            onMouseUp={handleMouseUp}
            onMouseMove={handleMouseMove}
            onTouchStart={handleTouchStart}
            onTouchMove={handleTouchMove}
            onTouchEnd={handleMouseUp}
          >
            {/* Show cards based on visibleCards */}
            {getVisibleAchievements().map((achievement, index) => (
              <div
                key={`${achievement.id}-${currentIndex}`}
                className="rounded-4 text-center position-relative flex-shrink-0"
                style={{
                  width: `calc(${100 / visibleCards}% - ${(visibleCards - 1) * 16}px)`,
                  minWidth: "300px",
                  height: "400px",
                  backgroundColor: "#FFFFFF",
                  transition: "all 0.3s ease",
                  overflow: "hidden",
                }}
              >
                {/* Logo Background Area */}
                <div
                  className="position-relative d-flex align-items-center justify-content-center"
                  style={{
                    height: "250px",
                    backgroundColor: "#d1d5db",
                    borderRadius: "1.5rem 1.5rem 0 0",
                  }}
                >
                  <img
                    src={achievement.logo}
                    alt="University Logo"
                    className="rounded"
                    style={{
                      width: "250px",
                      height: "250px",
                      objectFit: "contain",
                      padding: "8px",
                      mixBlendMode: "multiply",
                    }}
                  />

                  {/* White rounded cutout for percentage - extends to edge */}
                  <div
                    className="position-absolute"
                    style={{
                      bottom: "0px",
                      right: "0px",
                      width: "100px",
                      height: "65px",
                      backgroundColor: "#FFFFFF",
                      borderRadius: "25px 0 0 0",
                    }}
                  ></div>

                  {/* Percentage positioned in the cutout */}
                  <div
                    className="position-absolute fw-bold d-flex align-items-center"
                    style={{
                      bottom: "0px",
                      right: "0px",
                      width: "100px",
                      height: "65px",
                      fontSize: "2.5rem",
                      fontWeight: "800",
                      paddingLeft: "8px",
                      paddingRight: "8px",
                      background: "linear-gradient(90deg, #3F88BA, #161664)",
                      WebkitBackgroundClip: "text",
                      WebkitTextFillColor: "transparent",
                      backgroundClip: "text",
                    }}
                  >
                    {achievement.percentage}
                  </div>
                </div>

                {/* Content Area */}
                <div
                  className="p-4"
                  style={{
                    height: "150px",
                  }}
                >
                  <div className="mb-3">
                    <h4
                      className="fw-bold mb-0 text-start"
                      style={{
                        background: "linear-gradient(90deg, #00A491, #003E37)",
                        WebkitBackgroundClip: "text",
                        WebkitTextFillColor: "transparent",
                        backgroundClip: "text",
                        fontSize: "1.2rem",
                        letterSpacing: "0.5px",
                        textAlign: "left"
                      }}
                    >
                      {achievement.studentName}
                    </h4>
                  </div>

                  {/* Course with border */}
                  <div className="pt-3 border-top border-secondary">
                    <div className="d-flex gap-2">
                      <BookOpen size={16} />
                      <span
                        className="fw-semibold"
                        style={{
                          fontSize: "0.9rem",
                          letterSpacing: "0.5px",
                          background: "linear-gradient(90deg, #3F88BA, #161664)",
                          WebkitBackgroundClip: "text",
                          WebkitTextFillColor: "transparent",
                          backgroundClip: "text",
                        }}
                      >
                        {achievement.course}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Right Arrow */}
          <button
            onClick={handleNext}
            className="btn rounded-circle position-absolute d-flex align-items-center justify-content-center border-0 fade-in-section"
            data-scroll
            data-scroll-class="is-inview"
            data-scroll-repeat
            style={{
              background: "#1e40af",
              width: "48px",
              height: "48px",
              right: "-10px",
              top: "50%",
              transform: "translateY(-50%)",
              zIndex: 10,
              color: "white",
              animationDelay: "1.1s"
            }}
          >
            <img src="/assets/rar.png" alt="rightarr" width={50} height={50} />
          </button>
        </div>

        {/* Navigation Dots */}
        <div className="d-flex justify-content-center mt-4 gap-2">
          {Array.from({ length: achievements.length - visibleCards + 1 }).map((_, index) => (
            <button
              key={index}
              onClick={() => goToSlide(index)}
              className="border-0 rounded-circle"
              style={{
                width: "12px",
                height: "12px",
                backgroundColor: currentIndex === index ? "#1e40af" : "#d1d5db",
                transition: "all 0.3s ease",
                transform: currentIndex === index ? "scale(1.2)" : "scale(1)"
              }}
            />
          ))}
        </div>
      </div>

      <style jsx>{`
        .fade-in-section {
          opacity: 0;
          transform: translateY(20px);
          transition: opacity 0.6s ease-out, transform 0.6s ease-out;
        }
        .fade-in-section.is-inview {
          opacity: 1;
          transform: translateY(0);
        }
      `}</style>
    </div>
  );
}