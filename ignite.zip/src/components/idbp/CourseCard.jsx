"use client";
import React, { useState } from "react";
import { Plus, Minus } from "lucide-react";

function CourseCard() {
  const [activeIndex, setActiveIndex] = useState(0);

  const toggleAccordion = (index) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  const accordionItems = [
    {
      title: "PERSONALIZED BESPOKE TUTORING FOR MYP",
      bg: "rgba(231, 246, 255, 1)", // Lightest
    },
    {
      title: "PERSONALIZED BESPOKE TUTORING FOR MYP",
      bg: "rgba(214, 235, 252, 1)", // Slightly darker
    },
    {
      title: "PERSONALIZED BESPOKE TUTORING FOR MYP",
      bg: "rgba(197, 224, 250, 1)", // Midpoint
    },
    {
      title: "PERSONALIZED BESPOKE TUTORING FOR MYP",
      bg: "rgba(180, 213, 248, 1)", // Darker
    },
    {
      title: "PERSONALIZED BESPOKE TUTORING FOR MYP",
      bg: "rgba(163, 202, 245, 1)", // Final color
    },
  ];


  return (
    <div
      className="py-5 px-3 fade-in-section"
      data-scroll
      data-scroll-class="is-inview"
      data-scroll-repeat
      style={{ animationDelay: "0.1s" }}
    >
      <div className="container" style={{ maxWidth: "74.166vw" }}>
        {/* Header Section */}
        <div
          className="text-center mb-5 fade-in-section"
          data-scroll
          data-scroll-class="is-inview"
          data-scroll-repeat
          style={{ animationDelay: "0.15s" }}
        >
          <div
            className="d-flex align-items-center justify-content-center mb-3 gap-3 fade-in-section"
            data-scroll
            data-scroll-class="is-inview"
            data-scroll-repeat
            style={{ animationDelay: "0.2s" }}
          >
            <h1
              className="px-3 fw-bold text-uppercase fade-in-section"
              data-scroll
              data-scroll-class="is-inview"
              data-scroll-repeat
              style={{
                letterSpacing: "3px",
                background: "linear-gradient(135deg, #3F88BA, #161664)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                fontSize: "clamp(1rem, 2.5vw, 1.5rem)", // Responsive font size
                animationDelay: "0.3s",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: "0.5rem",
              }}
            >
              <img
                src="/assets/3color.png"
                alt="act"
                width={15}
                height={18}
                style={{ verticalAlign: "middle" }}
              />
              COURSES
              <img
                src="/assets/3color.png"
                alt="act"
                width={15}
                height={18}
                style={{ verticalAlign: "middle" }}
              />
            </h1>

          </div>

          <h2 className="fw-bold display-6 lh-tight mb-0">
            <span
              style={{
                background: "linear-gradient(135deg, #3F88BA, #161664)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
              }}
            >
              LOREM IPSUM DOLOR SIT AMET,
            </span>{" "}
            <span
              style={{
                background: "linear-gradient(135deg, #00A491, #003E37)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
              }}
            >
              CONSECTETUR
            </span>{" "}
            <span
              style={{
                background: "linear-gradient(135deg, #3F88BA, #161664)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
              }}
            >
              ADIPISCING
            </span>
          </h2>
        </div>

        {/* Accordion */}
        <div
          style={{
            borderRadius: "30px",
            overflow: "hidden",
            boxShadow: "0 0 8px rgb(0 0 0 / 0.1)",
            background: "linear-gradient(180deg, #E7F6FF 0%, #A3CAF5 100%)",
          }}
        >
          {accordionItems.map((item, index) => (
            <div key={index}>
              {/* Header */}
              <div
                className="d-flex justify-content-between align-items-center px-4 py-3"
                style={{
                  backgroundColor: item.bg,
                  color: item.textColor,
                  cursor: "pointer",
                  fontWeight: "bold",
                  fontSize: "0.95rem",
                  userSelect: "none",
                }}
                onClick={() => toggleAccordion(index)}
              >
                <span className="gradient-text">{item.title}</span>
                <span>{activeIndex === index ? <Minus size={20} /> : <Plus size={20} />}</span>
              </div>

              {/* Content */}
              {activeIndex === index && (
                <div
                  className="px-4 pb-4"
                  style={{
                    backgroundColor: item.bg,
                    color: "#374151",
                    fontSize: "0.9rem",
                  }}
                >
                  <div className="row g-3">
                    {/* Left Text */}
                    <div className="col-md-6">
                      <p style={{ marginTop: 0 }}>
                        An all-year-round MYP program thoughtfully designed to align with each
                        student's unique learning objectives.
                      </p>
                      <h5 className="fw-bold" style={{ fontSize: "0.85rem", color: item.textColor }}>
                        KEY HIGHLIGHTS
                      </h5>
                      <ul
                        className="list-unstyled"
                        style={{ fontSize: "0.8rem", color: "#374151" }}
                      >
                        {[
                          "Year-round personalized support for MYP students.",
                          "Customized lessons & flexible learning schedules.",
                          "One-on-one attention and personalized learning pace.",
                          "Continuous progress tracking with detailed feedback.",
                        ].map((point, i) => (
                          <li key={i} className="d-flex align-items-start">
                            <span
                              style={{
                                width: "6px",
                                height: "6px",
                                background: "#1e3a8a",
                                borderRadius: "50%",
                                marginTop: "6px",
                                marginRight: "10px",
                                flexShrink: 0,
                              }}
                            ></span>
                            {point}
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Right Image */}
                    <div className="col-md-6 d-flex justify-content-center">
                      <img
                        src="https://images.pexels.com/photos/5212345/pexels-photo-5212345.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop"
                        alt="Students studying together"
                        className="img-fluid rounded shadow"
                        style={{ height: "200px", objectFit: "cover" }}
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      <style jsx>{`
        .fade-in-section {
          opacity: 0;
          transform: translateY(20px);
          transition: opacity 0.5s ease-out, transform 0.5s ease-out;
        }
        .fade-in-section.is-inview {
          opacity: 1;
          transform: translateY(0);
        }
        /* Remove shadow from image inside accordion content */
        img.rounded.shadow {
          box-shadow: none !important;
          border-radius: 6px;
        }
          .gradient-text {
  background: linear-gradient(285.71deg, #3F88BA -4.32%, #161664 106.53%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;

  /* Optional for better browser support */
  background-clip: text;
  color: transparent;
}

      `}</style>
    </div>
  );
}

export default CourseCard;