// src/pages/index.js

export default function Index() {
  return null;
}
